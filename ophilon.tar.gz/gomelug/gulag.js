newbie = new Image();
newbie.src="../img/newbie.gif";
guru = new Image();
guru.src="../img/guru.gif";
comm = new Image();
comm.src="../img/forum.gif";
about = new Image();
about.src="../img/about.gif";